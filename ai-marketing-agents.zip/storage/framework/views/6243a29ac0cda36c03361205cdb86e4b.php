<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['heading' => $website->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($website->name)]); ?>
    <div class="mb-5 flex flex-wrap gap-2">
        <a href="<?php echo e(route('websites.edit', $website)); ?>" class="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-semibold">Edit</a>
        <form method="POST" action="<?php echo e(route('websites.audit', $website)); ?>"><?php echo csrf_field(); ?><button class="rounded-lg bg-navy px-4 py-2 text-sm font-semibold text-white">Run SEO Scan</button></form>
        <form method="POST" action="<?php echo e(route('websites.ai-insights.store', $website)); ?>"><?php echo csrf_field(); ?><button class="rounded-lg bg-teal px-4 py-2 text-sm font-semibold text-white">Generate AI Insight</button></form>
    </div>
    <section class="rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
        <a href="<?php echo e($website->url); ?>" target="_blank" rel="noopener" class="break-all text-teal"><?php echo e($website->url); ?></a>
        <div class="mt-4 grid gap-4 text-sm md:grid-cols-4"><div><span class="text-slate-500">Type</span><p class="font-semibold"><?php echo e(ucfirst($website->type)); ?></p></div><div><span class="text-slate-500">Language</span><p class="font-semibold"><?php echo e($website->language); ?></p></div><div><span class="text-slate-500">Location</span><p class="font-semibold"><?php echo e($website->target_location ?: 'Not set'); ?></p></div><div><span class="text-slate-500">Status</span><p class="font-semibold"><?php echo e(ucfirst($website->status)); ?></p></div></div>
    </section>
    <div class="mt-6 grid gap-6 xl:grid-cols-2">
        <?php echo $__env->make('websites.partials.audits', ['audits' => $website->seoAudits], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('websites.partials.insights', ['insights' => $website->aiInsights], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <section class="mt-6 rounded-lg border border-slate-200 bg-white shadow-soft">
        <div class="border-b border-slate-100 px-5 py-4"><h2 class="font-semibold text-navy">Marketing Tasks</h2></div>
        <div class="divide-y divide-slate-100"><?php $__empty_1 = true; $__currentLoopData = $website->marketingTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div class="px-5 py-4"><p class="font-semibold"><?php echo e($task->title); ?></p><p class="text-sm text-slate-500"><?php echo e(ucfirst($task->priority)); ?> · <?php echo e(str_replace('_',' ', $task->status)); ?></p></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="px-5 py-10 text-center text-sm text-slate-500">No tasks yet.</div><?php endif; ?></div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\dev\ai-marketing-agents\resources\views/websites/show.blade.php ENDPATH**/ ?>