<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['heading' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Dashboard']); ?>
    <div class="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
            <p class="text-sm font-medium text-slate-500">Total Websites</p>
            <p class="mt-3 text-4xl font-bold text-navy"><?php echo e($websiteCount); ?></p>
        </div>
        <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
            <p class="text-sm font-medium text-slate-500">Latest SEO Checks</p>
            <p class="mt-3 text-4xl font-bold text-navy"><?php echo e($latestAudits->count()); ?></p>
        </div>
        <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
            <p class="text-sm font-medium text-slate-500">Open Tasks</p>
            <p class="mt-3 text-4xl font-bold text-navy"><?php echo e($openTasks->count()); ?></p>
        </div>
        <div class="rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
            <p class="text-sm font-medium text-slate-500">Weekly Report</p>
            <p class="mt-3 text-lg font-bold text-navy"><?php echo e($latestReport?->status ?? 'Not generated'); ?></p>
        </div>
    </div>

    <div class="mt-6 grid gap-6 xl:grid-cols-3">
        <section class="rounded-lg border border-slate-200 bg-white shadow-soft xl:col-span-2">
            <div class="border-b border-slate-100 px-5 py-4"><h2 class="font-semibold text-navy">Latest SEO Checks</h2></div>
            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $latestAudits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between gap-4 px-5 py-4">
                        <div>
                            <p class="font-semibold"><?php echo e($audit->website->name); ?></p>
                            <p class="text-sm text-slate-500"><?php echo e($audit->page_title ?: 'No page title captured'); ?></p>
                        </div>
                        <span class="rounded-full px-3 py-1 text-xs font-semibold <?php echo e($audit->is_indexable ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'); ?>"><?php echo e($audit->is_indexable ? 'Indexable' : 'Review'); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="px-5 py-10 text-center text-sm text-slate-500">No SEO checks yet.</div>
                <?php endif; ?>
            </div>
        </section>

        <section class="rounded-lg border border-slate-200 bg-white shadow-soft">
            <div class="border-b border-slate-100 px-5 py-4"><h2 class="font-semibold text-navy">Latest AI Insights</h2></div>
            <div class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $latestInsights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="px-5 py-4">
                        <p class="font-semibold"><?php echo e($insight->title); ?></p>
                        <p class="mt-1 text-sm text-slate-500"><?php echo e($insight->website->name); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="px-5 py-10 text-center text-sm text-slate-500">Generate an insight from a website audit.</div>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <section class="mt-6 rounded-lg border border-slate-200 bg-white shadow-soft">
        <div class="border-b border-slate-100 px-5 py-4"><h2 class="font-semibold text-navy">Open Marketing Tasks</h2></div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead class="bg-slate-50 text-xs uppercase text-slate-500"><tr><th class="px-5 py-3">Task</th><th class="px-5 py-3">Website</th><th class="px-5 py-3">Priority</th><th class="px-5 py-3">Status</th></tr></thead>
                <tbody class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $openTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr><td class="px-5 py-4 font-semibold"><?php echo e($task->title); ?></td><td class="px-5 py-4"><?php echo e($task->website->name); ?></td><td class="px-5 py-4"><?php echo e(ucfirst($task->priority)); ?></td><td class="px-5 py-4"><?php echo e(str_replace('_', ' ', ucfirst($task->status))); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="px-5 py-10 text-center text-slate-500">No open tasks.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\dev\ai-marketing-agents\resources\views/dashboard.blade.php ENDPATH**/ ?>