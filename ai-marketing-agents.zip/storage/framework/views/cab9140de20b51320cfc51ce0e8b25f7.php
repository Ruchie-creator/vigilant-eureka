<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['heading' => 'Websites']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Websites']); ?>
    <div class="mb-5 flex justify-end"><a href="<?php echo e(route('websites.create')); ?>" class="rounded-lg bg-teal px-4 py-2 text-sm font-semibold text-white">Add Website</a></div>
    <div class="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        <?php $__empty_1 = true; $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="rounded-lg border border-slate-200 bg-white p-5 shadow-soft">
                <div class="flex items-start justify-between gap-3">
                    <div><h2 class="font-semibold text-navy"><?php echo e($website->name); ?></h2><a href="<?php echo e($website->url); ?>" class="mt-1 block break-all text-sm text-teal" target="_blank" rel="noopener"><?php echo e($website->url); ?></a></div>
                    <span class="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700"><?php echo e($website->status); ?></span>
                </div>
                <dl class="mt-5 grid grid-cols-3 gap-3 text-sm"><div><dt class="text-slate-500">Audits</dt><dd class="font-semibold"><?php echo e($website->seo_audits_count); ?></dd></div><div><dt class="text-slate-500">Insights</dt><dd class="font-semibold"><?php echo e($website->ai_insights_count); ?></dd></div><div><dt class="text-slate-500">Tasks</dt><dd class="font-semibold"><?php echo e($website->marketing_tasks_count); ?></dd></div></dl>
                <div class="mt-5 flex flex-wrap gap-2">
                    <a href="<?php echo e(route('websites.show', $website)); ?>" class="rounded-lg border border-slate-200 px-3 py-2 text-sm font-semibold">Open</a>
                    <form method="POST" action="<?php echo e(route('websites.audit', $website)); ?>"><?php echo csrf_field(); ?><button class="rounded-lg bg-navy px-3 py-2 text-sm font-semibold text-white">Scan</button></form>
                    <form method="POST" action="<?php echo e(route('websites.ai-insights.store', $website)); ?>"><?php echo csrf_field(); ?><button class="rounded-lg bg-teal px-3 py-2 text-sm font-semibold text-white">Generate AI Insight</button></form>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="rounded-lg border border-dashed border-slate-300 bg-white p-10 text-center text-slate-500 md:col-span-2 xl:col-span-3">Add the first healthcare website to begin monitoring.</div>
        <?php endif; ?>
    </div>
    <div class="mt-6"><?php echo e($websites->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\dev\ai-marketing-agents\resources\views/websites/index.blade.php ENDPATH**/ ?>